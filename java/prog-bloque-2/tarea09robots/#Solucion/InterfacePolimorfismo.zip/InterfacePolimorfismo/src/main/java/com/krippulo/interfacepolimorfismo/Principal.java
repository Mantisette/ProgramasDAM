    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.krippulo.interfacepolimorfismo;

import java.util.ArrayList;


class Principal {
    public static void main(String[] args) {
        //Array de robots con varios de cada tipo y los enciendo y apago todos
        Robot[] cacharros=new Robot[5];
        boolean esAndroide=true;
        for (int i = 0; i < cacharros.length; i++) {
            if(esAndroide){
                cacharros[i]=new Androide();//POLIMORFISMO en la asignación
            }else{
                cacharros[i]=new Barrefondos();//POLIMORFISMO en la asignación
            }
            cacharros[i].enciende();
            cacharros[i].apaga();
            esAndroide=!esAndroide;
        }
        System.out.println("-----------------------------------------------");
        System.out.println("-----------------------------------------------");
        
        //Array mezclando humanos y androides, y los hago saludar, reir y llorar
        //Puedo usar el interfaz como 'tipo' de datos!!!!!!!!!!!!!!
        Vida[] seres={new Humano("Ana"),//POLIMORFISMO en la asignación
            new Androide(),
            new Humano("Bea"),
            new Androide(),
            new Humano("Carlos"),
            new Androide()
        };
        for(Vida v:seres){
            v.decirLoQueSoy();
            metodoConInterfaz(v);
            v.saludar();//POLIMORFISMO en la ejecución
            v.reir();//POLIMORFISMO en la ejecución
            v.llorar();//POLIMORFISMO en la ejecución
            System.out.println("-----------------------------------------------");
        }
    }
    
    
    //Podemos usar el interfaz como tipo para un parámetro de un método!!!!!!!!
    //En ese caso, se puede invocar el método pasándole cualquier objeto
    //que implemente dicho interfaz
    //Este método es totalmente prescindible; sólo para demostrar que se puede
    static void metodoConInterfaz(Vida v){//POLIMORFISMO en la asignación
        System.out.println(v.identificarme());
        
    }
}
