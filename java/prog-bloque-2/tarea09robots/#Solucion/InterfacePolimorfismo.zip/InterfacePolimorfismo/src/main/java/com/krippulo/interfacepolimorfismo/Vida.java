/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.krippulo.interfacepolimorfismo;

/**
 *
 * @author krip
 */
public interface Vida {
    //Estos necesitan ser implementados explícitamente en cada clase que use la interface
    public void saludar();
    public void llorar();
    public String identificarme();
    
    //Estos no necesitan implementarse en la clases que usen la interface
    //aunque podrían sobreescribirse.
    default public void reir() {
        System.out.println(identificarme()+": ¡Ja, Ja!");
    }
    default public void decirLoQueSoy(){
        System.out.println("Soy un "+getClass().getSimpleName());
    }
}
