/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.krippulo.interfacepolimorfismo;

/**
 *
 * @author krip
 */
public abstract class Robot {
    private static int id=0;
    
    private String codigo;//lo dejo private porque no quiero que nadie lo pueda tocar

    public Robot(String s) {
        id++;
        this.codigo = s+id;
    }
    
    public void enciende(){
        System.out.println(codigo+": ...ON...");
    }
    
    public void apaga(){
        System.out.println(codigo+": ...OFF...");
    }

    public String getCodigo() {
        return codigo;
    }
   
}
