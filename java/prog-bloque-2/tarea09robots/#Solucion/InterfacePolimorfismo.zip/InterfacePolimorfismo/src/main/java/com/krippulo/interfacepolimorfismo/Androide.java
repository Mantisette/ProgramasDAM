/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.krippulo.interfacepolimorfismo;

/**
 *
 * @author krip
 */
public class Androide extends Robot implements Vida{

    public Androide() {
        super("And");
    }

    @Override
    public void saludar() {
        System.out.println(getCodigo()+": ¡Saludos! Bip-Bip");
    }

    @Override
    public void llorar() {
        System.out.println(getCodigo()+": ¡No quiero oxidarme!");
    }

    @Override
    public String identificarme() {
        return getCodigo();
    }
    
    
}
