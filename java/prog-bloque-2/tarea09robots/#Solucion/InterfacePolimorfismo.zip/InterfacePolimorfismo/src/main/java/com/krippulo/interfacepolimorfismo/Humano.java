/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.krippulo.interfacepolimorfismo;

/**
 *
 * @author krip
 */
public class Humano implements Vida{
    private String nombre;

    public Humano(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void saludar() {
        System.out.println(nombre+": ¡Hola!");
    }

    @Override
    public void llorar() {
        System.out.println(nombre+": ¡Snif, buaaaaah!");
    }

    @Override
    public String identificarme() {
        return nombre;
    }
    
    
}
